'use strict';
const { app, BrowserWindow } = require('electron');
const connectionManager = require('./lib/connectionManager');
const os = require("os");
const adapter = process.argv[2];
const interfaces = os.networkInterfaces();
const mapper = require('./middleware/mapper');
let peerIp;
let mainWindow;
let windows = {};

try {
  peerIp = interfaces[adapter][0].family === 'IPv4' ? interfaces[adapter][0].address : interfaces[adapter][1].address;
} catch ( e ) { console.log('select an adapter.'); process.exit(0); }

const init = () => {
  const fs = require('fs');
  if ( !fs.existsSync('./.keys') ) {
    fs.mkdirSync('./.keys');
  }
  mapper.set('connectionManager', new connectionManager(peerIp, 3000));
  const peerManager = mapper.get('connectionManager');

  try {
    // read contents of our key files if they already exist
    peerManager.setPublicKey( fs.readFileSync("./.keys/node.pub", "utf-8") );
    peerManager.setPrivateKey( fs.readFileSync("./.keys/node.priv", "utf-8") );
    peerManager.setPeerId( peerManager.generatePeerId( peerManager.getPublicKey) );
    console.log(peerManager.getPeerId);
    createWindow();
  } catch ( err ) {}
  if ( !peerManager.getPublicKey || !peerManager.getPrivateKey ) {
    // generate a new keypair as none were found
    console.log("Generating KeyPair...");
    setTimeout(() => {
      const NodeRSA = require('node-rsa');
      const key = new NodeRSA();
      key.generateKeyPair(2048, 65537);
      const publicDer = key.exportKey('pkcs8-public');
      const privateDer = key.exportKey('pkcs8-private');

      fs.writeFileSync( "./.keys/node.pub", publicDer, ( err ) => console.log( err ) );
      fs.writeFileSync( "./.keys/node.priv", privateDer, ( err ) => console.log( err ) );
      peerManager.setPublicKey( fs.readFileSync("./.keys/node.pub", "utf-8") );
      peerManager.setPrivateKey( fs.readFileSync("./.keys/node.priv", "utf-8") );
      console.log("Keys generated.");
      peerManager.setPeerId( peerManager.generatePeerId( peerManager.getPublicKey) );
      console.log(peerManager.getPeerId);
      createWindow();
    }, 500);
  }
}

const createWindow = () => {
  mainWindow = new BrowserWindow({
    width: 1920,
    height: 1080,
    webPreferences: {
      nodeIntegration: true
    }
  });

  mainWindow.loadFile('public/index.html');
  
  mainWindow.webContents.on('did-finish-load', () => {
    mapper.set('rendererWindow', mainWindow);
    // init
    const node = require('./lib/node');
    new node();

    setTimeout(() => {
      
      require('./middleware/messageHandler');
    }, 5000);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.on('ready', init);

app.on('window-all-closed', () => {
  app.quit(); 
  mapper.get('connectionManager').sendDisconnectMessage({
    peerId: mapper.get('connectionManager').getPeerId
  })
  process.exit(0);
});
app.on('activate', () => { if ( mainWindow === null ) createWindow(); });