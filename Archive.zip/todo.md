## Todo
- write known host code to pull from config file
- write ban mechanism
- enable encryption on payload content
- store username in localstorage?
- patch image sizes?
- private messaging
- adapter selection
    - store in local storage or similar?

- test builds!!