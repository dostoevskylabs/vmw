const { ipcRenderer } = require('electron');
let username;

let activeUsers = {};

function addUser ( peerId, username ) {
  activeUsers[ peerId ] = username;
}

function getUsername( peerId ){
  return activeUsers[peerId];
}

function removeUser ( peerId, username ) {
  delete activeUsers[ peerId ];
}

function changeUsername ( peerId, username ) {
  activeUsers[ peerId ] = username;
}

function listUsers() {
  let userArray = [];
  for ( let peerId of Object.keys(activeUsers) ) {
    userArray.push(activeUsers[peerId]);
  }
  return userArray;
}

var shell = require('electron').shell;

function sendSync( type, object ) {
	ipcRenderer.sendSync('synchronous-message', {
		type: type,
		content: object
	})
}

function send( type, object ) {
	ipcRenderer.send('asynchronous-message', {
		type: type,
		content: object
	});
}

username = localStorage.getItem('username') || 'Anonymous';

setTimeout(() => {
  if ( username !== 'Anonymous') {
    send('username', {
      username: username
    });
  }

}, 10000);


/**
 * Paste at cursor position
 * 
 * https://stackoverflow.com/questions/6014702/how-do-i-detect-shiftenter-and-generate-a-new-line-in-textarea/6015906#6015906
 */
function pasteIntoInput(el, text) {
  el.focus();
  if (typeof el.selectionStart == "number"
          && typeof el.selectionEnd == "number") {
      var val = el.value;
      var selStart = el.selectionStart;
      el.value = val.slice(0, selStart) + text + val.slice(el.selectionEnd);
      el.selectionEnd = el.selectionStart = selStart + text.length;
  } else if (typeof document.selection != "undefined") {
      var textRange = document.selection.createRange();
      textRange.text = text;
      textRange.collapse(false);
      textRange.select();
  }
}

function magic(input) {
  //input = input.replace(/&/g, '&amp;');
  //input = input.replace(/</g, '&lt;');
  //input = input.replace(/>/g, '&gt;');
  return input;
}

class messageStore {
  constructor () {
    this.storage = localStorage;
    if ( !this.storage.getItem('messages') ) {
      this.storage.setItem('messages', '[]');
    }

  }

  clearMessages () {
    this.storage.setItem('messages', '[]');
  }

  getMessages () {
    return JSON.parse(this.storage.getItem('messages'));
  }

  addMessage ( data ) {
    let currentMessages = Array.from(JSON.parse(this.storage.getItem('messages')));
    currentMessages.push( data );
    this.storage.setItem('messages', JSON.stringify(currentMessages));
  }
}

class UI {
  constructor () {
    this.input = document.getElementById("input");
    this.output = document.getElementById("output");
		this.menu = document.getElementById("menu");
		
    this.addTab({ tabId : 'dashboard', tabName : 'Dashboard' });
    this.state = 'dashboard';
    this.changeTab = undefined;

    this.messageStore = new messageStore();
    this.previousMessages = this.messageStore.getMessages();
  
    for ( let i = 0; i < this.previousMessages.length; i++ ) {
      this.print( this.previousMessages[i], 'log' );
      if ( i === ( this.previousMessages.length - 1 ) ) {
        setTimeout( () => {
          this.output.scrollTop = this.output.scrollHeight;
        }, 500);
      }
    }

    this.input.addEventListener( "keydown", this.inputKeydown.bind( this ) );
	}
	
	onData( object ) {
		console.log(object);
		switch ( object.type ) {
      case 'manualConnectionFailed':
        this.print({
          type: 'error',
          timestamp: Date.now(),
          peerId: undefined,
          username: 'Connection to Peer Failed',
          message: `${object.content.peerIp}:${object.content.peerPort}`
        }, 'error');
      break;

      case 'cmdSuccessful':
        console.log(object);
        this.print({
          "type": 'message',
          "timestamp": Date.now(),
          "peerId"   : undefined,
          "username" : username + ' ran the command: ' + object.content.cmd,
          "message"  : `\`\`\`bash
${object.content.stdout}\`\`\``
        });
      break;

      case 'peerDiscovered':
        /**
        this.print({
          type: 'notice',
          timestamp: Date.now(),
          peerId: object.content.peerId,
          username: 'Peer Discovered',
          message: object.content.peerId
        }, 'notice');
        **/
      break;

      case 'changeUsernameMessage':
        this.print({
          type: 'notice',
          timestamp: Date.now(),
          peerId: object.content.peerId,
          username: `${getUsername(object.content.peerId)} changed their username to ${object.content.username}`,
          message: ''
        }, 'notice');
        changeUsername( object.content.peerId, object.content.username );
      break;

      case 'connectionSuccessful':
        this.print({
          type: 'notice',
          timestamp: Date.now(),
          peerId: object.content.peerId,
          username: 'Connection Established With Peer',
          message: object.content.peerId
        }, 'notice');

      break;

      case 'peerConnectedToNode':
        this.print({
          type: 'notice',
          timestamp: Date.now(),
          peerId: object.content.peerId,
          username: 'Peer Has Joined Your Node',
          message: object.content.peerId
        }, 'notice');        

        addUser( object.content.peerId, object.content.username );
      break;

      case 'peerDisconnectedFromNode':
        this.print({
          type: 'error',
          timestamp: Date.now(),
          peerId: object.content.peerId,
          username: 'Peer Has Left Your Node',
          message:  object.content.peerId
        }, 'error');

        removeUser( object.content.peerId );
      break;

			case 'publicMessage':
				this.print({
          "type": 'message',
					"timestamp": Date.now(),
					"peerId"   : object.content.peerId,
					"username" : object.content.username,
					"message"  : object.content.message
				});
			break;
		}
	}

  tabClick ( event ) {
    console.log( 'clicked: ' + event.currentTarget.dataset.tabid );
	}
	
	onInput ( data ) {
    if ( data.message[0] === '/' ) {
      const cmd = data.message.split('/')[1].split(' ')[0];
      const args = data.message.split(`/${cmd} `)[1];
      switch ( cmd ) {
        case 'help':
          let data = {
            type: 'warning',
            peerId: undefined,
            username: 'Available Commands',
            message: `/help - this menu
            /clear - clear screen
            /username {username} - set username
            /cmd {cmd} - execute command and print results
            /list - list users
            /exit - quit`
          }
          this.print(data, 'warning');
        break;

        case 'list':
        {
        let data = {
          type: 'warning',
          peerId: undefined,
          username: 'Active Users',
          message: listUsers().join(', ')
        }
        this.print(data, 'warning');
        }
        break;

        case 'clear':
          this.output.innerHTML = '';
          this.messageStore.clearMessages();
        break;
        
        case 'exit':
          send('exit', {});
        break;

        case 'connect':
          send('connect', {
            peerIp: args.split(' ')[0],
            peerPort: args.split(' ')[1]
          });
        break;

        case 'cmd':
          send('cmd', {
            cmd: args
          })
        break;

        case 'username':
          username = args;
          localStorage.setItem('username', username);
          send('username', {
            username: username
          });
        break;

        default:
          console.log('unknown');
      }
    } else {
      // msg
			send( "publicMessage", {
				username: data.username,
				message: data.message
			});

      this.print({
        "type": 'message',
        "timestamp": Date.now(),
        "username" : data.username,
        "message"  : data.message
			});
		}

	}

  addTab ( data ) {

    let elNode = UI.HTMLElement("div", {
      "class"       : "node",
      "style"       : "background-color:#a0555c;",
      "id"          : data.tabId,
      "data-tabid" : data.tabId
    });

    let elIndicator = UI.HTMLElement("div", {
      "class" : "nodeIndicator"
    });

    let elTitle = UI.HTMLElement("div", {
      "class" : "nodeTitle"
    }, data.tabName);

    let elRight = UI.HTMLElement("div", {
      "class" : "nodeRight"
    });

    let elAddress = UI.HTMLElement("div", {
      "class" : "nodeAddress"
    }, `${data.tabId}`);

    elNode.addEventListener("click", this.tabClick.bind( this ), false);

    elNode.appendChild(elIndicator);
    elNode.appendChild(elTitle);
    elNode.appendChild(elRight);
    elNode.appendChild(elAddress);

    this.menu.appendChild( elNode );
  }

  static HTMLElement ( tag, props, innerText = null ) {
    let el = document.createElement( tag );
    for ( const [key, value] of Object.entries( props ) ) {
      el.setAttribute( key, value );
    }
    if ( innerText ) {
      el.innerText = innerText;
    }

    return el;
  }

  inputKeydown ( event ) {
    if ( event.key === 'Enter' ) {
      event.preventDefault();
      if ( event.shiftKey && event.target.value !== '' ) {
        const rows = event.target.value.split('\n').length;
        if ( rows > 4 ) {
          event.target.style.top = (event.target.style.top.split('px')[0] - 20) + 'px';
        }
        //event.target.style.height = (event.target.scrollHeight) + "px";
        pasteIntoInput(event.target, '\n');
      } else if ( !event.shiftKey ) {
        const data = {
          "username" : username,
          "message"  : event.target.value
        };
        event.target.value = '';
        event.target.style.top = 0 + 'px';
        this.onInput( data );
      }
    }
  }

  createEntry ( data ) {
    let entry;

    const time = Intl.DateTimeFormat("en-US", {
      hour: "numeric", minute: "numeric", second: "numeric"
    }).format( data.timestamp );

    if ( data.hasOwnProperty("type") ) {
      switch ( data.type ) {
        case "blank":
          break;
        case "error":
          data.username = "\uf06a " + data.username;
          break;
        case "notice":
          data.username = "\uf0f3 " + data.username;
          break;
        case "warning":
          data.username = "\uf071 " + data.username;
          break;
        case "code":

        break;
        case "message":

        break;
        case undefined:
          break;
        default:
          console.error(`Invalid Type "${data.type}"`);
      }
    }

    data.message = magic(data.message);
      entry = `
      <div class="msgContainer">
        <div class="entry ${data.type ? data.type : ''}">
          <time class="date" datetime="${data.timestamp}">${time}</time>
          <div data-id="${data.peerId}" class="user ${data.type ? "fa" : ''}">${data.username}</div>
        </div>
        <div class="msg">${md.render(data.message)}</div>
      </div>`;

      return entry;
  }

  print ( data, type = 'default' ) {
    if ( data ) {
      const newEntry = this.createEntry( data );
      if ( newEntry ) {
        this.output.insertAdjacentHTML("beforeend", newEntry);
        if ( type === 'command' ) {
          return;
        }

        if ( type === 'default' ) {
          //shell.beep();
          this.messageStore.addMessage( data );
        }
        
        let test = this.output.querySelectorAll('a');
        let test2 = test[test.length -1];

        if ( test2 ) {
          test2.addEventListener('click', function( event ){
            if ( event.target.href ) {
              event.preventDefault();
              shell.openExternal( event.target.href, { activate: true } );
            }
          });
        }

        this.output.scrollTop = this.output.scrollHeight;
      }
    }
  }
}

let ui = new UI();
ipcRenderer.on('message', ( event, object ) => {
	ui.onData( object );
});

ipcRenderer.on('asynchronous-reply', ( event, object ) => {
	ui.onData( object );
});

ipcRenderer.on('synchronous-reply', ( event, object  ) => {
	ui.onData( object );
});