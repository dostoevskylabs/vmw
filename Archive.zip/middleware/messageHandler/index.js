const { ipcMain } = require('electron');
const mapper = require('../mapper');

function test ( event, object ) {
  switch ( object.type ) {
    case 'exit':
      mapper.get('connectionManager').sendDisconnectMessage({
        peerId: mapper.get('connectionManager').getPeerId
      })
      process.exit(0);
    break;

    case 'username':
      console.log(object.content.username);
      mapper.get('connectionManager').setUsername(object.content.username);
      mapper.get('connectionManager').changeUsernameMessage({
        peerId: mapper.get('connectionManager').getPeerId,
        username: object.content.username
      })
    break;

    case 'cmd':
      const { exec } = require('child_process');
      exec(object.content.cmd, (err, stdout, stderr) => {
        if ( err ) {
          return;
        }
        
        event.reply('asynchronous-reply', {
          type: 'cmdSuccessful',
          content: {
            cmd: object.content.cmd,
            stdout,
            stderr
          }
        }); 
        //console.log(`stdout: ${stdout}`);
        //console.log(`stderr: ${stderr}`);
      });
    break;

    case 'connect':
      mapper.get('connectionManager').connectToPeer( object.content.peerIp, object.content.peerPort, function( res ){
        if ( res ) {
          event.reply('asynchronous-reply', {
            type: 'manualConnectionSuccesful',
            content: {}
          }); 
        } else {
          event.reply('asynchronous-reply', {
            type: 'manualConnectionFailed',
            content: {
              peerIp: object.content.peerIp,
              peerPort: object.content.peerPort
            }
          }); 
        }
      });

    break;

    case 'publicMessage':
      mapper.get('connectionManager').sendPublicMessage({
        peerId: mapper.get('connectionManager').getPeerId,
        username: object.content.username,
        message: object.content.message
      });
    break;

    case 'test-sync':
      console.log('test-sync');
      event.returnValue = {
        type: 'sync-reply',
        content: {}
      };
    break;

    case 'test-async':
      console.log('test-async');
      event.reply('asynchronous-reply', {
        type: 'async-reply',
        content: {}
      });      
    break;

    default:
      console.log('unhandled');
  }
}

ipcMain.on('asynchronous-message', (event, arg) => {
  test(event, arg);
});

ipcMain.on('synchronous-message', (event, arg) => {
  test(event, arg);
});