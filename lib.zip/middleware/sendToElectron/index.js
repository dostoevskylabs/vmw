const mapper = require('../mapper');

class sendToElectron {
    static send( object ) {
        mapper.get('rendererWindow').webContents.send('message', object);
    }

}

module.exports = sendToElectron;