let mapDb = {};

class Mapper {
    static set( key, instance ) {
        mapDb[key] = instance;
    }

    static get ( key ) {
        return mapDb[key];
    }
}

module.exports = Mapper;